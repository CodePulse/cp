<?php

namespace Drush\Role;

class RoleException extends \Exception {}
